"""
Time Series Forecasting for Revenue and Profit.

This script aggregates monthly revenue and profit from the sales dataset and
builds time series models to forecast future values.  It demonstrates how to
use **SARIMA** from the `statsmodels` library.  If you install the optional
`prophet` package, you can switch to Prophet for potentially better
performance on complex seasonality.

Forecasts and evaluation metrics (MAE, RMSE, MAPE) are printed to the
console.  Forecast plots are saved in the `forecasting/` directory.
"""

import os
from dataclasses import dataclass
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_absolute_error, mean_squared_error

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
OUTPUT_DIR = os.path.dirname(__file__)
os.makedirs(OUTPUT_DIR, exist_ok=True)


def load_sales_data() -> pd.DataFrame:
    sales_path = os.path.join(DATA_DIR, 'sample_sales_data.csv')
    sales = pd.read_csv(sales_path, parse_dates=['OrderDate'])
    return sales


def prepare_monthly_series(sales: pd.DataFrame) -> pd.DataFrame:
    """Aggregate monthly revenue and profit and return a DataFrame with a datetime index."""
    df = sales.copy()
    df['Month'] = df['OrderDate'].dt.to_period('M').dt.to_timestamp()
    monthly = df.groupby('Month').agg(revenue=('Sales', 'sum'), profit=('Profit', 'sum')).reset_index()
    monthly.set_index('Month', inplace=True)
    return monthly


def train_test_split(series: pd.Series, test_periods: int = 3):
    """Split a time series into training and test sets."""
    train = series.iloc[:-test_periods]
    test = series.iloc[-test_periods:]
    return train, test


def build_sarima_model(train: pd.Series, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12)):
    """Fit a SARIMA model to the training data."""
    model = SARIMAX(train, order=order, seasonal_order=seasonal_order, enforce_stationarity=False, enforce_invertibility=False)
    results = model.fit(disp=False)
    return results


def evaluate_forecast(actual: pd.Series, forecast: pd.Series):
    """Compute MAE, RMSE and MAPE between actual and forecast values."""
    mae = mean_absolute_error(actual, forecast)
    rmse = np.sqrt(mean_squared_error(actual, forecast))
    mape = np.mean(np.abs((actual - forecast) / actual)) * 100
    return mae, rmse, mape


def plot_forecast(series: pd.Series, forecast: pd.Series, future_forecast: pd.Series, title: str, filename: str):
    """Plot actual vs. forecast values and save the figure."""
    fig, ax = plt.subplots(figsize=(10, 5))
    series.plot(ax=ax, label='Actual')
    forecast.plot(ax=ax, label='Forecast (Test)', style='--')
    future_forecast.plot(ax=ax, label='Future Forecast', style=':')
    ax.set_title(title)
    ax.set_xlabel('Month')
    ax.set_ylabel('Value')
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, filename))
    plt.close(fig)


def main():
    sales = load_sales_data()
    monthly = prepare_monthly_series(sales)

    for metric in ['revenue', 'profit']:
        print(f"\n=== Forecasting {metric.capitalize()} ===")
        series = monthly[metric]
        train, test = train_test_split(series)

        # Fit SARIMA model
        model_results = build_sarima_model(train)
        # Forecast on test period
        pred = model_results.get_forecast(steps=len(test))
        forecast = pred.predicted_mean
        # Evaluate
        mae, rmse, mape = evaluate_forecast(test, forecast)
        print(f"MAE:  {mae:.2f}")
        print(f"RMSE: {rmse:.2f}")
        print(f"MAPE: {mape:.2f}%")

        # Forecast future (next 3 periods)
        future_steps = 3
        future_pred = model_results.get_forecast(steps=len(test) + future_steps)
        future_forecast = future_pred.predicted_mean[-future_steps:]

        # Plot
        combined_test_forecast = pd.concat([test, forecast], axis=1)
        plot_forecast(
            series,
            forecast=pd.Series(forecast.values, index=test.index),
            future_forecast=pd.Series(future_forecast.values, index=pd.date_range(test.index[-1] + pd.offsets.MonthBegin(), periods=future_steps, freq='MS')),
            title=f"{metric.capitalize()} Forecast",
            filename=f"{metric}_forecast.png"
        )
        print(f"Forecast for next {future_steps} months:")
        print(future_forecast)


if __name__ == '__main__':
    main()