"""
AI Recommendation Engine

This script takes the analytical outputs from the EDA and risk modules and
generates human‑readable recommendations for management.  The logic is
rule‑based but can be extended with machine learning or natural language
generation techniques.  Each recommendation is accompanied by a rationale.
"""

import os
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')

def load_sales_data():
    sales_path = os.path.join(DATA_DIR, 'sample_sales_data.csv')
    return pd.read_csv(sales_path, parse_dates=['OrderDate'])

def load_expense_data():
    expense_path = os.path.join(DATA_DIR, 'sample_expenses_data.csv')
    return pd.read_csv(expense_path, parse_dates=['Month'])

def aggregate_data(sales: pd.DataFrame, expenses: pd.DataFrame):
    sales['Month'] = sales['OrderDate'].dt.to_period('M').dt.to_timestamp()
    monthly = sales.groupby('Month').agg(revenue=('Sales', 'sum'), profit=('Profit', 'sum')).reset_index()
    exp = expenses.groupby('Month').agg(total_expense=('Expense', 'sum')).reset_index()
    monthly = monthly.merge(exp, on='Month', how='left').fillna(0)
    # Calculate margins
    monthly['profit_margin'] = monthly['profit'] / monthly['revenue']
    monthly['expense_ratio'] = monthly['total_expense'] / monthly['revenue']
    return monthly

def generate_recommendations(monthly: pd.DataFrame, sales: pd.DataFrame) -> list:
    """Generate a list of recommendation strings based on data trends."""
    recommendations = []
    # 1. Expense vs revenue
    avg_expense_ratio = monthly['expense_ratio'].mean()
    if avg_expense_ratio > 0.5:
        recommendations.append(
            f"Average expenses account for {avg_expense_ratio:.0%} of revenue. Consider reducing operational or marketing costs or increasing prices to improve margins."
        )
    # 2. Identify underperforming product categories
    category_perf = sales.groupby('Category').agg(revenue=('Sales', 'sum'), profit=('Profit', 'sum'))
    worst_category = category_perf['profit'].idxmin()
    worst_margin = category_perf.loc[worst_category, 'profit'] / category_perf.loc[worst_category, 'revenue']
    recommendations.append(
        f"The {worst_category} category has the lowest profitability (margin: {worst_margin:.1%}). Investigate pricing, sourcing or promotional strategies for this category."
    )
    # 3. Identify declining profit margins
    monthly_sorted = monthly.sort_values('Month')
    monthly_sorted['margin_change'] = monthly_sorted['profit_margin'].pct_change()
    if any(monthly_sorted['margin_change'] < -0.10):
        recommendations.append(
            "Profit margins have declined by more than 10% in recent months. Review cost drivers and consider renegotiating supplier contracts or streamlining operations."
        )
    # 4. Marketing spend vs sales growth (assuming marketing is part of expenses)
    # Here we approximate marketing spend as 20% of total expenses
    marketing_ratio = 0.2
    monthly['marketing_spend'] = monthly['total_expense'] * marketing_ratio
    monthly['revenue_growth'] = monthly['revenue'].pct_change()
    monthly['marketing_growth'] = monthly['marketing_spend'].pct_change()
    if monthly['marketing_growth'].mean() > monthly['revenue_growth'].mean():
        recommendations.append(
            "Marketing spend is growing faster than revenue. Evaluate marketing ROI and reallocate budget to high‑performing channels."
        )
    # 5. Customer concentration risk
    customer_revenue = sales.groupby('CustomerID')['Sales'].sum().sort_values(ascending=False)
    top_customers = customer_revenue.head(5)
    top_share = top_customers.sum() / customer_revenue.sum()
    if top_share > 0.3:
        recommendations.append(
            f"Top five customers account for {top_share:.0%} of revenue. Develop strategies to diversify the customer base to reduce concentration risk."
        )
    return recommendations


def main():
    sales = load_sales_data()
    expenses = load_expense_data()
    monthly = aggregate_data(sales, expenses)
    recs = generate_recommendations(monthly, sales)
    print("=== Recommendations ===")
    for rec in recs:
        print(f"- {rec}")


if __name__ == '__main__':
    main()