# Data Folder

This folder contains synthetic datasets used to demonstrate the functionality of the **AI‑Powered Financial Intelligence Dashboard**.  You can replace these files with real datasets from your business or from public sources such as Kaggle.

## Files

| File | Description |
|------|-------------|
| `sample_sales_data.csv` | 500 synthetic sales records from 2021–2022.  Columns include `OrderID`, `OrderDate`, `ShipDate`, `ShipMode`, `CustomerID`, `Segment`, `Region`, `ProductID`, `Category`, `SubCategory`, `Sales`, `Quantity`, `Discount` and `Profit`.  Profits are randomly generated to simulate typical profit margins. |
| `sample_expenses_data.csv` | Monthly expenses for five departments (Operations, Marketing, R&D, HR, IT) over the same period.  Columns: `Month`, `Department`, `Expense`. |

### Using Your Own Data

To perform a realistic analysis, replace these CSV files with your own data:

1. **Sales data:** Should include at minimum: order date, product identifier, sales amount, cost or profit, customer identifier and any segmentation variables (e.g. region, category, segment).  Additional columns (discounts, cost of goods sold, returns) will enrich the analysis.
2. **Expense data:** Should include: date, department/category and expense amount.  If expenses are available at a more granular level (e.g. marketing channel or cost centre), adjust the scripts accordingly.

After adding your data, run the scripts in `notebooks/`, `forecasting/` and `risk_analysis/` to generate updated insights and recommendations.