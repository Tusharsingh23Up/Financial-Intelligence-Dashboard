-- Example SQL queries for computing financial KPIs.
-- These queries assume a PostgreSQL database with a table named `sales`
-- that mirrors the `sample_sales_data.csv` structure.  Adjust table and
-- column names as needed.

-- 1. Monthly revenue and profit
SELECT
    DATE_TRUNC('month', OrderDate) AS month,
    SUM(Sales) AS revenue,
    SUM(Profit) AS profit
FROM sales
GROUP BY DATE_TRUNC('month', OrderDate)
ORDER BY month;

-- 2. Gross and net profit margins
SELECT
    month,
    revenue,
    profit,
    (profit / revenue) AS gross_margin,
    (profit / revenue) AS net_margin  -- In this simplified dataset, gross = net
FROM (
    SELECT DATE_TRUNC('month', OrderDate) AS month,
           SUM(Sales) AS revenue,
           SUM(Profit) AS profit
    FROM sales
    GROUP BY DATE_TRUNC('month', OrderDate)
) sub;

-- 3. Year‑over‑year revenue growth
WITH monthly AS (
    SELECT DATE_TRUNC('month', OrderDate) AS month,
           SUM(Sales) AS revenue
    FROM sales
    GROUP BY DATE_TRUNC('month', OrderDate)
)
SELECT
    m1.month,
    m1.revenue AS current_revenue,
    m2.revenue AS revenue_last_year,
    (m1.revenue - m2.revenue) / NULLIF(m2.revenue, 0) AS yoy_growth
FROM monthly m1
LEFT JOIN monthly m2 ON m2.month = m1.month - INTERVAL '1 year'
ORDER BY m1.month;

-- 4. Customer Lifetime Value (CLV)
-- Estimate CLV as total revenue per customer; for a more accurate
-- calculation, include customer lifespan and repeat frequency.
SELECT
    CustomerID,
    SUM(Sales) AS customer_revenue,
    AVG(Sales) AS average_order_value,
    COUNT(*) AS order_count
FROM sales
GROUP BY CustomerID;

-- 5. Return on Investment (ROI)
-- This query assumes there is a separate table `marketing_spend` with
-- columns (Month date, Investment numeric).  Replace `investment_cost`
-- with your actual cost column.
SELECT
    s.month,
    s.revenue - s.profit AS net_profit, -- if cost of goods sold is not captured separately
    m.investment_cost,
    (s.revenue - s.profit) / NULLIF(m.investment_cost, 0) * 100 AS roi_percentage
FROM (
    SELECT DATE_TRUNC('month', OrderDate) AS month,
           SUM(Sales) AS revenue,
           SUM(Profit) AS profit
    FROM sales
    GROUP BY DATE_TRUNC('month', OrderDate)
) s
JOIN marketing_spend m ON m.month = s.month;

-- These queries serve as starting points for calculating KPIs in SQL.
-- Adapt them to fit your schema and business logic.