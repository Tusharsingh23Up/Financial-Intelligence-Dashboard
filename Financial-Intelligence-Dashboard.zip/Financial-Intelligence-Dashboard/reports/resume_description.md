# Résumé Description

**AI‑Powered Financial Intelligence Dashboard** – *Financial Analyst / Data Scientist*

- Designed and implemented a comprehensive financial intelligence system in Python to simulate an enterprise‑level analytics workflow.
- Developed a modular architecture covering revenue analytics, profitability analysis, expense tracking, customer segmentation, forecasting and risk detection.
- Engineered data pipelines to clean, aggregate and join sales and expense data; computed KPIs such as revenue growth, gross/net margins, EBITDA, ROI and customer lifetime value.
- Built time series forecasting models (SARIMA/Prophet) to predict revenue and profit; evaluated performance using MAE, RMSE and MAPE.
- Implemented a rule‑based risk analytics module to detect declining profit margins, revenue drops and spending anomalies; generated automated alerts and recommendations.
- Created an AI recommendation engine that translates analytical insights into actionable business suggestions, enhancing decision making for executives.
- Designed a corporate‑style dashboard layout with KPI cards, trend charts, heatmaps and segmentation filters, enabling interactive exploration in Power BI or Tableau.
- Authored detailed reports and presentation materials to communicate methodology, findings and strategic recommendations to stakeholders.