# Executive Summary

This executive summary highlights the key findings of the **AI‑Powered Financial Intelligence Dashboard** project.  The objective of the project is to build a business‑focused analytics platform that helps management understand past performance, predict future outcomes, detect financial risks and receive actionable recommendations.

## Data and Methodology

* **Data sources:** A synthetic sales dataset with 500 transactions across 2021–2022 and a synthetic monthly expense dataset were used for demonstration.  Each sales record contains order date, region, product category, sales amount and profit.  Each expense record lists a department and total cost per month.
* **Exploratory analysis:** Data were cleaned, aggregated by month and enriched with derived variables such as revenue growth, profit margin and expense ratio.  Customer metrics (e.g. lifetime value and churn) were computed by grouping transactions by customer ID.
* **Time series forecasting:** Revenue and profit were aggregated monthly and modelled using a seasonal ARIMA (SARIMA) model.  Forecast accuracy was assessed with MAE, RMSE and MAPE.
* **Risk analysis:** Rule‑based heuristics identified months with sharp declines in revenue or profit, expense spikes, and high expense‑to‑revenue ratios.
* **Recommendation engine:** A simple rules engine converted analytical findings into business suggestions (e.g. reduce expenses, investigate low‑margin categories).

## Key Metrics

| Metric | Value | Insight |
|-------|------:|--------|
| **Total Revenue (2021–2022)** | **$496,948.95** | The business generated nearly half a million dollars in sales over two years. |
| **Total Profit** | **$143,781.71** | Net earnings before non‑operational adjustments. |
| **Gross/Net Margin** | **28.93 %** | About 29 % of revenue translates to profit; however expenses are high relative to revenue. |
| **Estimated EBITDA** | **$143,781.71** | Since taxes, interest and depreciation are zero in the synthetic data, EBITDA equals net profit.  In a real setting, EBITDA helps investors evaluate operational profitability【659903020970897†L281-L308】. |
| **Approx. ROI** | **144.66 %** | Assuming marketing spend equals 20 % of revenue, the ROI is high.  ROI compares net profit to investment cost and guides resource allocation【920962903768014†L249-L260】. |
| **Average CLV** | **$2,745.57** | On average, each customer contributes about $2.7k in sales over the two‑year period.  Understanding CLV helps prioritise high‑value customers and increase retention【877156729879924†L213-L221】【877156729879924†L242-L256】. |
| **Churn Rate** | **33.81 %** | One third of customers who purchased in the first year did not return in the second; retention strategies are needed. |

## Insights

* **Revenue and profit trends:** Revenue fluctuated markedly, with significant drops in several months.  Profit tracked revenue closely because expenses were fixed in this synthetic example.  The average gross margin was ~29 %.  Several spikes in revenue corresponded to high‑volume months.
* **Customer behaviour:** A small group of customers generated a disproportionate share of profit.  The top five customers accounted for over 10 % of total profit.  The **Furniture** category had the lowest profitability, suggesting pricing or cost issues.
* **Forecasting:** The SARIMA model predicted declining revenue and profit for the three months following December 2022, with MAE of about $11.9k for revenue and $5.2k for profit.  High MAPE values (~43 % and ~69 %) indicate considerable uncertainty and potential need for more sophisticated models or more data.
* **Risk alerts:** The risk module flagged multiple months where profit margins fell more than 10 % month‑over‑month and where revenue dropped more than 20 %.  Many months showed expenses exceeding 60 % of revenue and expense spikes above 25 %, pointing to unsustainable cost structures.

## Recommendations

1. **Control operating expenses:** Average expenses exceeded 500 % of revenue in the synthetic data; while this exaggerates reality, companies should monitor expense ratios.  Reduce discretionary spending and renegotiate supplier contracts.
2. **Improve profitability of low‑margin categories:** The furniture category has the lowest margin (about 27 %).  Review pricing, sourcing and promotional strategies for this segment.
3. **Diversify the customer base:** Top customers contribute a large portion of revenue.  Develop marketing campaigns to acquire and retain a broader mix of customers to mitigate concentration risk.
4. **Align marketing spend with revenue growth:** Track marketing spend relative to revenue and adjust budgets to maximise ROI.  If marketing expenditure is rising faster than revenue, reallocate funds to high‑return channels.
5. **Enhance forecasting accuracy:** Collect more granular data (weekly or daily) and explore additional models (e.g. Prophet, machine learning) to improve forecast precision and support inventory and resource planning.

These insights and recommendations demonstrate how the financial intelligence dashboard can inform strategic decision making.  With real data and an interactive dashboard, management could drill down into departments, regions and product lines, monitor KPIs in real time and act on AI‑powered recommendations.