# Interview Questions & Answers – Financial Intelligence Dashboard

This document provides sample interview questions and suggested answers to help you discuss your **AI‑Powered Financial Intelligence Dashboard** project during internship or job interviews.  The questions focus on business understanding, technical skills and strategic thinking.

## 1. What motivated you to build this project?

**Answer:**  I wanted to create a portfolio project that simulates the work of a financial analyst in a corporate setting.  Instead of a simple stock prediction tutorial, I built an end‑to‑end system that analyses revenue, profit, expenses and customer behaviour, forecasts future performance, detects risks and generates business recommendations.  My goal was to demonstrate proficiency in data engineering, analytics, forecasting and dashboard design while providing insights that matter to executives.

## 2. Which key performance indicators (KPIs) did you calculate and why?

**Answer:**  I calculated metrics such as revenue growth, gross margin, net profit margin, EBITDA, ROI, customer lifetime value (CLV) and churn rate.  These KPIs are widely used in finance and business because they reveal different aspects of performance.  For example, EBITDA measures operational profitability without financing and accounting effects【659903020970897†L281-L308】, ROI evaluates whether investments generate adequate returns【920962903768014†L249-L260】, and CLV quantifies the long‑term value of customers【877156729879924†L213-L221】.  Including a diverse set of metrics ensures a holistic view of the business.

## 3. How did you handle data cleaning and preparation?

**Answer:**  I used Pandas to load and clean the data.  I removed records with missing or non‑positive sales and converted date columns to datetime types.  I created a `Month` column to enable monthly aggregation.  For customer analysis, I grouped transactions by customer ID to compute CLV and churn.  I also joined the sales and expense datasets on the month dimension to analyse profit margins and expense ratios.

## 4. Can you explain the forecasting approach you used?

**Answer:**  I aggregated revenue and profit by month and split the series into training and testing sets.  I fitted a seasonal ARIMA (SARIMA) model using the `statsmodels` library.  The model captures both autoregressive and seasonal patterns, which makes it suitable for time series with possible seasonality.  I evaluated the model using MAE, RMSE and MAPE metrics.  The forecasts showed a downward trend for the next three months, although the high MAPE indicated uncertainty.  In future work I would experiment with Prophet or machine‑learning models to improve accuracy.

## 5. How did you perform risk analysis?

**Answer:**  I implemented a rule‑based system that scanned monthly data for red flags.  The rules flagged months where profit margins declined by more than 10 %, revenue dropped by more than 20 %, expenses exceeded 60 % of revenue or expenses spiked by more than 25 % relative to the previous month.  When a rule was triggered, an alert was generated for that month.  In a production environment, I would augment this with statistical anomaly detection techniques to reduce false positives.

## 6. What is the role of the recommendation engine?

**Answer:**  The recommendation engine translates analytical results into actionable business insights.  For example, it might notice that average expenses exceed half of revenue and recommend reducing costs, or it might identify that a particular product category has low profitability and suggest reviewing pricing strategies.  The engine also assesses marketing efficiency, profit margin trends and customer concentration risk.  In the future, I could employ natural language generation to produce more nuanced narrative recommendations.

## 7. How would you extend this project for a real company?

**Answer:**  I would integrate live data from ERP and CRM systems, build more robust data pipelines and implement automated anomaly detection.  For forecasting, I would include exogenous variables such as promotional events, seasonality and macroeconomic indicators.  I would also deploy the dashboard in Power BI or Tableau with interactive filters and user‑level security.  Finally, I would work closely with stakeholders to ensure the KPIs and recommendations align with strategic objectives.

## 8. What challenges did you encounter and how did you address them?

**Answer:**  One challenge was working with synthetic data, which can produce unrealistic patterns (e.g. expenses exceeding revenue).  I addressed this by focusing on the methodology rather than the absolute numbers and by clearly stating assumptions.  Another challenge was balancing technical depth with business relevance; I prioritised clarity and narrative storytelling in the dashboard design and reports.