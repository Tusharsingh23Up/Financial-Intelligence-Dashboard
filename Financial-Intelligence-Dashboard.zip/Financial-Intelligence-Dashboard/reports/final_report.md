# AI‑Powered Financial Intelligence Dashboard – Final Report

## Introduction

Financial analysts at modern companies must synthesise large volumes of data to assess performance, manage risk and advise leadership.  Traditional spreadsheet analyses often fail to capture complex relationships between revenue, expenses and customer behaviour, and they seldom scale to the needs of executives who require real‑time insight.  This project delivers a **comprehensive financial intelligence dashboard** that combines data engineering, statistical modelling and AI to answer critical business questions such as: *Why did revenue change? Which products or customers drive profit? Which regions are underperforming? What risks exist and what actions should management take?*

## Business Problem

A hypothetical retail/e‑commerce company wants to understand its financial performance over the last two years, forecast future trends and detect early warning signs of financial distress.  Management needs a tool that consolidates revenue, profit, expense and customer data into a single platform with clear visualisations and narrative recommendations.  The dashboard should facilitate strategic decisions about pricing, marketing budgets, cost control and customer retention.

## Literature Review

Key financial metrics and techniques underpin this project:

* **EBITDA** – Earnings before interest, taxes, depreciation and amortisation.  It measures operating profitability by excluding financing and accounting decisions.  Investors and lenders use EBITDA to compare companies across industries and assess cash‑flow generation【659903020970897†L281-L308】.
* **Return on Investment (ROI)** – Calculated as `(Net Profit / Cost of Investment) × 100%`.  ROI helps businesses evaluate whether an investment is worthwhile and is particularly useful when assessing marketing campaigns or capital projects【920962903768014†L249-L260】.  However, ROI does not account for timing, depreciation or non‑financial benefits and should be considered alongside other metrics【920962903768014†L249-L260】.
* **Customer Lifetime Value (CLV)** – The total revenue expected from a customer over the duration of their relationship.  Understanding CLV helps businesses target high‑value customers and tailor retention strategies【877156729879924†L213-L221】【877156729879924†L242-L256】.
* **Time Series Forecasting** – Uses historical, time‑stamped data to predict future outcomes and inform strategic decisions【574833942692337†L79-L97】.  Forecasting models such as SARIMA and Prophet capture trends and seasonality, enabling companies to plan inventory, staffing and budgets.

## Methodology

1. **Data Collection:**  Synthetic datasets were created to simulate sales transactions and monthly expenses.  Each sales record includes order date, ship date, region, product category, sales amount, quantity, discount and profit.  Expenses cover departments like Operations, Marketing, R&D, HR and IT.
2. **Data Cleaning:**  The data were loaded using Pandas, missing values were removed, and records with non‑positive sales were discarded.  Dates were converted to datetime objects.
3. **Aggregation and KPI Calculation:**  Sales were aggregated by month.  Revenue, profit and margins were computed along with growth rates (month‑over‑month and year‑over‑year).  Additional KPIs (EBITDA, ROI, CLV, churn rate) were calculated using user‑defined functions.  SQL queries were provided to replicate these calculations in a database environment.
4. **Exploratory Analysis:**  Trend plots were created for revenue and profit, and profit margins were analysed over time.  Top customers and products were identified based on profit contributions.  Customers were segmented by lifetime value.
5. **Forecasting:**  Monthly revenue and profit series were modelled using a seasonal ARIMA (SARIMA) model.  The last three months were held out for testing.  Forecasts for the test set and the next three months were produced, and error metrics (MAE, RMSE, MAPE) were computed.
6. **Risk Analysis:**  A rule‑based system scanned the monthly aggregates for patterns indicating financial stress: sharp drops in revenue (>20 %), declines in profit margin (>10 %), high expense ratios (>60 % of revenue) and expense spikes (>25 % increase).
7. **Recommendation Engine:**  A rules engine converted analytical findings into plain‑language recommendations.  It considered expense levels, product profitability, margin trends, marketing efficiency and customer concentration.
8. **Dashboard Design:**  A clean, corporate dashboard layout was proposed, with KPI cards, trend charts, heatmaps, segmentation filters and risk indicators.  Guidance was provided for implementing the dashboard in Power BI or Tableau.

## Data Cleaning & Preparation

The sales dataset contained 500 rows covering January 2021 to December 2022.  100 % of rows had valid dates, sales and profit values after cleaning.  A derived `Month` column facilitated monthly aggregation.  Expenses data were aggregated by month and joined with sales data to compute profit margins and expense ratios.

## Exploratory Data Analysis

### Revenue & Profit Trends

Monthly revenue ranged from about **$5,939** to **$31,423** with no clear seasonal pattern due to the synthetic nature of the data.  Profit followed revenue, maintaining a relatively stable gross margin of **~29 %**.  However, several months experienced dramatic drops: revenue decreased by more than **62 %** between February and March 2021, and by **80 %** between May and June 2022.

### Customer & Product Insights

* **Top customers:**  The five most profitable customers generated more than **$10,000** in profit combined.  Targeting and retaining these high‑value customers could yield significant returns.
* **Category performance:**  The **Furniture** category had the lowest profit margin (~27 %), whereas other categories performed better.  Potential causes include high production costs or discounting.  Pricing strategies and supplier negotiations should be reviewed.
* **Customer retention:**  About **34 %** of customers churned (i.e., they purchased in the first year but not the second), indicating a need for loyalty programs or targeted marketing.

### KPI Analysis

* **EBITDA:**  Equal to net profit in the synthetic dataset, EBITDA underscores operating profitability and can be compared across companies【659903020970897†L281-L308】.
* **ROI:**  Assuming marketing spend equals 20 % of revenue, ROI was approximately **145 %**, suggesting strong returns on investment; however, this is artificially high due to data assumptions.  ROI helps assess the efficacy of marketing campaigns and capital projects【920962903768014†L249-L260】.
* **CLV:**  Average customer lifetime value was **$2,745.57**, highlighting the revenue potential of each customer.  Prioritising high‑value customers and enhancing retention strategies could increase long‑term profitability【877156729879924†L213-L221】【877156729879924†L242-L256】.

## Forecasting Results

The SARIMA model achieved **MAE ≈ $11.9 k**, **RMSE ≈ $13.6 k** and **MAPE ≈ 43 %** for revenue forecasting, indicating moderate accuracy.  Profit forecasting was less accurate (MAPE ~69 %), reflecting higher volatility in profit data.  The model predicted declining revenue and profit for the three months after December 2022, underscoring the importance of monitoring external factors (e.g., seasonality, marketing campaigns) and considering more advanced models or additional data.

## Risk Analytics

Multiple risk signals were detected:

* **Profit margin decline:**  Four months experienced margin declines greater than 10 % relative to the previous month (e.g. June 2021 and June 2022).  Such declines could signal rising costs or revenue problems.
* **Revenue drops:**  Several months recorded revenue decreases greater than 20 %, with the steepest drop (~80 %) between May and June 2022.
* **High expense ratios:**  Expenses exceeded 60 % of revenue in every month, with some months approaching 800 % (an artefact of synthetic data).  In a real business, expense ratios above 60 % would warrant cost‑control measures.
* **Expense spikes:**  Expenses increased by more than 25 % month‑over‑month in six instances (e.g. April 2021, May 2021, May 2022).  Unexpected spikes may reflect poorly controlled spending.

These signals highlight the need for ongoing monitoring and early intervention to maintain financial stability.

## Business Recommendations

1. **Optimise cost structure.**  Given the high expense ratios, management should conduct a comprehensive cost review to identify inefficiencies.  This may include renegotiating supplier contracts, reducing discretionary spend and implementing zero‑based budgeting.
2. **Improve product profitability.**  The furniture category underperforms; consider revisiting product pricing, sourcing cheaper materials or streamlining the product line to focus on high‑margin items.
3. **Diversify the customer base.**  With a few customers contributing a large share of revenue, the company faces concentration risk.  Invest in marketing campaigns to attract new customers and reduce dependency on a handful of accounts.
4. **Align marketing spend with returns.**  Track marketing ROI closely.  If spending grows faster than revenue, reallocate budgets toward high‑return channels and discontinue underperforming campaigns.
5. **Enhance forecasting and data collection.**  Collect finer‑grained data (weekly or daily) and incorporate external factors (e.g. seasonality, promotions).  Evaluate alternative models such as Prophet or machine‑learning algorithms to improve prediction accuracy【574833942692337†L79-L97】.
6. **Implement an early‑warning system.**  Incorporate the risk rules into an automated monitoring system that alerts management when key indicators deteriorate.  Augment the rules with statistical anomaly detection for more nuanced insights.

## Conclusion

The **AI‑Powered Financial Intelligence Dashboard** combines data engineering, analytics and AI to deliver a holistic view of business performance.  It demonstrates how financial metrics, customer analysis, forecasting and risk detection can be unified into a single platform that supports strategic decision making.  While the synthetic data exaggerates certain patterns, the methodologies employed are directly applicable to real‑world datasets.  By adopting this system, organisations can move beyond static reports and towards proactive, data‑driven management.

## Future Scope

* **Integration with real data sources:**  Connect the dashboard to ERP, CRM and marketing systems to ingest live data.
* **Advanced forecasting models:**  Explore Prophet, SARIMA with exogenous variables (SARIMAX) and machine‑learning models (e.g. XGBoost, LSTM) for more accurate predictions.
* **Automated anomaly detection:**  Implement statistical techniques (e.g. Z‑score, isolation forests) to detect anomalies without hard‑coded rules.
* **Natural language generation:**  Use language models to automatically draft narrative insights and executive summaries from the analytics results.
* **Self‑service dashboard:**  Deploy the dashboard in Power BI or Tableau with user‑friendly filters and drill‑down capabilities.

This project serves as a template for building enterprise‑level financial intelligence systems that combine technical rigour with business relevance.