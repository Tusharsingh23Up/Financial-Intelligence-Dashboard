"""
Risk Analysis Module

This script scans the aggregated sales and expenses data for signs of financial
stress.  It uses simple rule‑based heuristics to detect potential risks such
as:

* Sharp declines in revenue or profit margin
* Rapid increases in expenses
* Expenses that consume an unusually large share of revenue

If any risk conditions are met, the script prints a descriptive alert.  This
logic can be extended with more sophisticated anomaly detection algorithms.
"""

import os
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')


def load_data():
    sales_path = os.path.join(DATA_DIR, 'sample_sales_data.csv')
    expenses_path = os.path.join(DATA_DIR, 'sample_expenses_data.csv')
    sales = pd.read_csv(sales_path, parse_dates=['OrderDate'])
    expenses = pd.read_csv(expenses_path, parse_dates=['Month'])
    return sales, expenses


def aggregate_monthly(sales: pd.DataFrame, expenses: pd.DataFrame) -> pd.DataFrame:
    """Aggregate monthly revenue, profit and expenses."""
    sales['Month'] = sales['OrderDate'].dt.to_period('M').dt.to_timestamp()
    monthly_sales = sales.groupby('Month').agg(revenue=('Sales', 'sum'), profit=('Profit', 'sum')).reset_index()
    monthly_expenses = expenses.groupby('Month').agg(total_expense=('Expense', 'sum')).reset_index()
    monthly = monthly_sales.merge(monthly_expenses, on='Month', how='left').fillna(0)
    # Compute profit margin and expense ratio
    monthly['profit_margin'] = monthly['profit'] / monthly['revenue']
    monthly['expense_ratio'] = monthly['total_expense'] / monthly['revenue']
    return monthly


def detect_risks(monthly: pd.DataFrame) -> list:
    """Identify months where risk conditions are met and return a list of alerts."""
    alerts = []
    # Sort by Month
    monthly = monthly.sort_values('Month').reset_index(drop=True)
    # 1. Declining profit margin (more than 10% decrease compared to previous month)
    monthly['margin_change'] = monthly['profit_margin'].pct_change()
    for i in range(1, len(monthly)):
        if monthly.loc[i, 'margin_change'] < -0.10:
            alerts.append((monthly.loc[i, 'Month'], f"Profit margin dropped {monthly.loc[i, 'margin_change']*100:.1f}% vs previous month"))
    # 2. Revenue drop > 20% compared to previous month
    monthly['revenue_change'] = monthly['revenue'].pct_change()
    for i in range(1, len(monthly)):
        if monthly.loc[i, 'revenue_change'] < -0.20:
            alerts.append((monthly.loc[i, 'Month'], f"Revenue decreased {monthly.loc[i, 'revenue_change']*100:.1f}% vs previous month"))
    # 3. Expense ratio above 60% of revenue
    for _, row in monthly.iterrows():
        if row['expense_ratio'] > 0.60:
            alerts.append((row['Month'], f"Expenses ({row['total_expense']:.2f}) exceed 60% of revenue ({row['revenue']:.2f})"))
    # 4. Expense spike (>25% increase month‑over‑month)
    monthly['expense_change'] = monthly['total_expense'].pct_change()
    for i in range(1, len(monthly)):
        if monthly.loc[i, 'expense_change'] > 0.25:
            alerts.append((monthly.loc[i, 'Month'], f"Expenses increased {monthly.loc[i, 'expense_change']*100:.1f}% compared to previous month"))
    return alerts


def main():
    sales, expenses = load_data()
    monthly = aggregate_monthly(sales, expenses)
    alerts = detect_risks(monthly)
    if alerts:
        print("=== Risk Alerts ===")
        for month, message in alerts:
            print(f"{month.strftime('%Y-%m')}: {message}")
    else:
        print("No significant risks detected.")


if __name__ == '__main__':
    main()